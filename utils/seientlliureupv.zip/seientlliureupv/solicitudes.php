<?php

session_start();

include("include/bbdd.php");

if( isset($_POST['contrasenya']) ) { 

  if( $_POST['contrasenya']=="peque2006" ){ 
 
     $_SESSION['autorizado']=1; 
  
  } 
 
}

if(isset($_GET['id'])){
 
 $id=$_GET['id'];
 
 //capturo el email necesario
 $ssql8 = "SELECT * FROM solicitudes WHERE id='".$id."'";
 $resultConsul8 = mysql_query($ssql8);
 $rowConsul8=mysql_fetch_object($resultConsul8);
 $email=$rowConsul8->email;
 
 function generar_codigo() {
	  $uno=rand(65,90);
	  $tres=rand(65,90);
	  $cinco=rand(65,90);
	  $dos=fmod(($uno*$tres),25) + 65;
	  $cuatro=fmod(($tres*$cinco),25) + 65;
	  $final=chr($uno).chr($dos).chr($tres).chr($cuatro).chr($cinco);
	  return $final;
  }
 
  //creo un array con todos los codigos ya usados
  $array_codigos=array();
  $ssql = "SELECT * FROM codigos";
  $resultConsul = mysql_query($ssql);
  while( $rowConsul=mysql_fetch_object($resultConsul) ) {
    array_push($array_codigos,$rowConsul->codigo);
  }
   
  $iterando=true;
  while( $iterando==true ) {   
    $codigo_temp=array();     
    $cod=generar_codigo(); 
    array_push($codigo_temp,$cod);
	if( sizeof(array_intersect($codigo_temp,$array_codigos))==0 ) { $iterando=false; };	
  }
  $codigo=array_pop($codigo_temp);
  //este codigo ya es bueno: no ha sido usado
  
	  $asunto="C�digo de activaci�n para mipeque.es";
	  $body="<br><img src=\"http://www.mipeque.es/images/logoMiPeque.gif\">"."<p style=\"font-family:Verdana; font-size:10px;\"><br>Su c�digo de activaci�n para mipeque.es es: <b>".$codigo."</b><br><br>Puede ir a la p�gina de registro aqu�: <a href=\"http://www.mipeque.es/registro.php?codigo=".$codigo."\">http://www.mipeque.es/registro.php?codigo=".$codigo."</a><br><br></p><br><br><p style=\"font-family:Verdana; font-size:10px;\">Servicio ofrecido por: <a href=\"http://www.dusnic.com\"><br><img border=\"0\" src=\"http://www.mipeque.es/images/dusnicLogo.gif\"></a></p>";

	  $headers = "From:$email\nReply-To:$email\n";
      $headers .= "X-Mailer:PHP/".phpversion()."\n";
      $headers .= "Mime-Version: 1.0\n";
      $headers .= "Content-Type: text/html";

 	  //mail al usuario
	  mail($email, $asunto, $body, $headers);
	  
	  //insertamos solicitud aceptada
	  $ssql9 = "INSERT INTO aceptadas (nombre,email,navegador,ip,fecha) VALUES ('".$rowConsul8->nombre."','".$rowConsul8->email."','".$rowConsul8->navegador."','".$rowConsul8->ip."',now())";
	  $resultConsul9 = mysql_query($ssql9);	  	  
	  
	  //baja de la bbdd
	  $ssql8 = "DELETE FROM solicitudes WHERE id='".$id."'";
	  $resultConsul8 = mysql_query($ssql8);

	  header('Location: solicitudes.php?ok=1');
 
	
} else {

?>

<html>
<head>
<title>MiPeque.es | by DUSNIC | albums de fotos para su peque</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="DESCRIPTION" content="Albums de fotos en Flash para su Peque">
<meta name="KEYWORDS" content="album flash dusnic peque mipeque fotos bebe personal albums peque�o peque�a ni�o ni�a baby photoalbum photo">
<META NAME="OWNER" CONTENT="info@mipeque.es">
<META NAME="AUTHOR" CONTENT="Dusnic S.L">
<META NAME="RATING" CONTENT="General">
<link href="estilos.css" rel="stylesheet" type="text/css">
<?php include("./include/head.php"); ?>
</head>

<body>
	
	<div id="container" style="background:url(/images/<?php	echo "main_background_".rand(1, 2).".jpg";?>);">
	
	<div id="logo">
		<a href="index.php"><img src="images/logoMiPeque.gif" alt="Mi peque punto es (logotipo)" /></a>
	</div>
	
	<div id="cuerpo">
	
	 <?php 
	 
	 if (!isset($_SESSION['autorizado'])) {
	  
	    ?>
	    
	      <p>Secci�n protegida con contrase�a.</p>
	    
	      <form action="solicitudes.php" method="post">	    
	        Password: <input type="password" name="contrasenya"> <input type="submit" value="validar">
	      </form>
	    
	    <?php
		
	 } else {
	 
	 ?>
	 
	<div style="display:none"> 
	
	 	<p><b>Hay <?php $ssql2 = "SELECT * FROM solicitudes"; $resultConsul2 = mysql_query($ssql2); $rows=mysql_num_rows($resultConsul2); echo $rows; ?> solicitudes pendientes:</b></p>
	
	</div>
	 
	 <div id="contenido" style="width:330px;height:280px;overflow:auto">
	
	    <?php if(isset($_GET['ok'])){ echo "<p><img src=\"info.gif\"> C�digo de activaci�n enviado.</p>"; } ?>
	    
	    <?php if(isset($_GET['borrar'])){ echo "<p><img src=\"info.gif\"> Entrada borrada.</p>"; } ?>		
				
		<?php
		
		echo "<p>Envio de c�digo de activaci�n autom�tico.</p><p>&nbsp;</p>";
		
		$ssql8 = "SELECT * FROM solicitudes ORDER BY fecha DESC";
		$resultConsul8 = mysql_query($ssql8);
		while($rowConsul8=mysql_fetch_object($resultConsul8)){
		  //echo "<div style=\"border:1px solid #000000; margin:10px; padding:8px;\">".$rowConsul8->nombre."<br><a href=\"mailto:".$rowConsul8->email."\">".$rowConsul8->email."</a><br><b>ip:</b> ".$rowConsul8->ip."<br><b>browser:</b> ".$rowConsul8->navegador."<br><span style=\"color:0000FF;\">".$rowConsul8->fecha."</span><br>"."<br> (<a href=\"solicitudes.php?id=".$rowConsul8->id."\">ENVIAR C�DIGO</a> | <a href=\"solicitudes2.php?id=".$rowConsul8->id."\">BORRAR ENTRADA</a>)</div>"; 	
		}		
		
	    ?>
	    
	    <p style="font-size:10px">Utilidades: <a href="stats.php">Stats</a>, <a href="size.php">Size</a>, <a href="boletines.php">Boletines</a>, <a href="filethingie.php">Filethingie</a>, <a href="gen_code.php">GenCode</a>, <a href="listados.php">Listados</a>, <a href="ls.php">LS</a>, <a href="phpinfo.php">phpinfo</a>.</p>
	    
	    <?php
	  
	  
	  } //fin de else de autorizaci�n
		
		?>		
     </div>
     
	</div>
</div>

</body>
</html>
<?php

}

?>