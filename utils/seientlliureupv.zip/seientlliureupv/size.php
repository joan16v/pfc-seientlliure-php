<?php

error_reporting(0);

?>
<html>
<head>
<title>MiPeque.es | Informaci�n del espacio en disco ocupado</title>
<style>
table {
	color:#FFFFFF;
	font-family:Verdana; 
	font-size:10px;
}

a {
	color:#FFFFFF;
	text-decoration:none;
}

a:hover {
	color:#FFFFFF;
	text-decoration:underline;
}

</style>
</head>
<body style="background-color:#000000; color:#FFFFFF; font-family:Verdana; font-size:10px">

<h1>Informaci�n del espacio en disco ocupado</h1>
<h2>mipeque.es</h2>

<?php

include('include/bbdd.php');

function getDirectorySize($path)
{
  $totalsize = 0;
  $totalcount = 0;
  $dircount = 0;
  if ($handle = opendir ($path))
  {
    while (false !== ($file = readdir($handle)))
    {
      $nextpath = $path . '/' . $file;
      if ($file != '.' && $file != '..' && !is_link ($nextpath))
      {
        if (is_dir ($nextpath))
        {
          $dircount++;
          $result = getDirectorySize($nextpath);
          $totalsize += $result['size'];
          $totalcount += $result['count'];
          $dircount += $result['dircount'];
        }
        elseif (is_file ($nextpath))
        {
          $totalsize += filesize ($nextpath);
          $totalcount++;
        }
      }
    }
  }
  closedir ($handle);
  $total['size'] = $totalsize;
  $total['count'] = $totalcount;
  $total['dircount'] = $dircount;
  return $total;
}

function sizeFormat($size)
{
    if($size<1024)
    {
        return $size." bytes";
    }
    else if($size<(1024*1024))
    {
        $size=round($size/1024,1);
        return $size." KB";
    }
    else if($size<(1024*1024*1024))
    {
        $size=round($size/(1024*1024),1);
        return $size." MB";
    }
    else
    {
        $size=round($size/(1024*1024*1024),1);
        return $size." GB";
    }

} 

$path=".";
$ar=getDirectorySize($path);

echo "Espacio ocupado total : ".sizeFormat($ar['size'])."<br>";
echo "N�mero de archivos : ".$ar['count']."<br>";
echo "N�mero de directorios : ".$ar['dircount']."<br>";

echo "<br><br>";

echo "<table border=\"0\">";
echo "<tr><td><b>Directorio</b></td><td><b>Espacio ocupado</b></td><td></td></tr>";


//esta funcion pinta una linea segun el espacio en disco
function printimages($input) {
 
  $devolver="";
  for($i=1; $i<$input; $i++) {
	$devolver=$devolver."<img src=\"images/red.gif\"><img src=\"images/red.gif\">";
  }

  return $devolver;

}

//consulta la bbdd para saber los directorios en disco
$ssql8 = "SELECT * FROM usuarios";
$resultConsul8 = mysql_query($ssql8);
while($rowConsul8=mysql_fetch_object($resultConsul8)){
    $siz=getDirectorySize($rowConsul8->login);    
    $tam=round(($siz['size']/500000)*10,0);
	if( $siz['size']<600000 ){ echo "<tr><td><a target=\"_blank\" href=\"/".$rowConsul8->login."\">".$rowConsul8->login."</a></td><td>".sizeFormat($siz['size'])."</td><td>".printimages($tam)."</td></tr>"; }
}

echo "</table>";

?>

<p align="center" style="font-size:10px;">MiPeque.es | size.php | Informaci�n de espacio en disco usado</p>

</body>
</html>