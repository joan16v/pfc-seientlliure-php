<html>
<head>
<title>MiPeque.es | by DUSNIC | Ayuda</title>
<link href="estilos.css" rel="stylesheet" type="text/css">
</head>

<body>

<div id="container" style="background:url(images/main_background_ayuda.jpg);">

	 <div id="ayuda">
	  <div id="ayuda_dentro">

		<table border="0"><tr valign="middle"><td><img src="/images/ayuda_big.jpg"></td><td style="font-size:14px;font-family:Verdana"><b>Ayuda</b></td></tr></table>
		
		<p>Ayuda de la zona de administraci�n. [ <a href="http://www.mipeque.es">Volver</a> ]</p>
		
		<ul>
		  <li><b>Muestra tu �lbum!</b> <br><br>Aqu� podr� mostrar a algun amigo suyo el �lbum de su peque. Simplemente introduzca el nombre y el e-mail de su amigo y pulse enviar.<br><br></li>
		  <li><b>Recomendar la web a un amigo</b> <br><br>Si le parece que mipeque.es le puede interesar a alguien que conoce, desde aqu� le puede informar.<br><br></li>
		  <li><b>Mandar invitaci�n</b> <br><br>Para registrarse en mipeque.es es necesario un c�digo de activaci�n. Puede invitar hasta a 10 personas a que creen su cuenta en mipeque.es mand�ndoles una invitaci�n, que les proporcionar� el c�digo de activaci�n necesario.<br><br></li>		  
		  <li><b>Editar datos</b> <br><br>Aqu� podr� modificar los datos personales que introdujo al registrarse.<br><br></li>		  		  
		  <li><b>Administrar �lbum</b> <br><br>Desde esta opci�n podr� crear y modificar el �lbum de su peque.<br><br></li>		  		  
		  <li><b>Ver �lbum</b> <br><br>�C�mo habr� quedado el �lbum despu�s de las modificaciones hechas? Aqu� puede ver el resultado.<br><br></li>			  
  		  <li><b>Cerrar sesi�n</b> <br><br>Esta opci�n es para salir de su cuenta. Tendr� que volver a introducir su nombre de �lbum y contrase�a para volver a entrar en el futuro. Si est� usando un PC compartido (biblioteca, unviersidad, etc.) recuerde cerrar la sesi�n al acabar de usar mipeque.es!<br><br></li>	
		</ul>
		
		<p>&nbsp;</p>
		
		<p>Ayuda de Administrar �lbum. [ <a href="javascript:history.back();">Volver</a> ]</p>		
		
		<table border="0">
		<tr>
		  <td><br><img src="/images/icon_galeria.jpg" alt="Galer�a de im�genes"></td><td><b>Galer�a de im�genes</b><br><br>Haga clic para desplegar su galer�a de im�genes. Desde aqu� podr� a�adir y borrar fotos. Haga otra vez clic para esconder la galer�a.</td>
		</tr>
		<tr>
		  <td><br><img src="/images/icon_addfoto.jpg" alt="A�adir imagen"></td><td><b>A�adir imagen</b><br><br>Pulse en este icono para a�adir a su galer�a de im�genes una foto de su disco duro.</td>
		</tr>
		<tr>
		  <td><br><img src="/images/icon_addpag.jpg" alt="Insertar p�gina"></td><td><b>Insertar p�gina</b><br><br>Inserta una nueva p�gina a su �lbum.</td>
		</tr>
		<tr>
		  <td><br><img src="/images/icon_quitarpag.jpg" alt="Eliminar p�gina actual"></td><td><b>Eliminar p�gina actual</b><br><br>Elimina la p�gina en la cual nos encontremos, con todo su contenido.</td>
		</tr>
		<tr>
		  <td><br><img src="/images/icon_addtext.jpg" alt="Insertar texto"></td><td><b>Insertar texto</b><br><br>Haga clic aqu� si desea insertar un texto a su �lbum.</td>
		</tr>
		<tr>
		  <td><br><img src="/images/icon_papelera.jpg" alt="Eliminar elemento"></td><td><b>Eliminar elemento</b><br><br>Elimina el elemento que tengamos seleccionado, ya sea una imagen o un texto.</td>
		</tr>
		<tr>
		  <td><br><img src="/images/icon_rotar1.jpg" alt="Rotar a la izquierda"></td><td><b>Rotar a la izquierda</b><br><br>Rota 90 grados a la izquierda la imagen seleccionada.</td>
		</tr>
		<tr>
		  <td><br><img src="/images/icon_rotar2.jpg" alt="Rotar a la derecha"></td><td><b>Rotar a la derecha</b><br><br>Rota 90 grados a la derecha la imagen seleccionada.</td>
		</tr>
		<tr>
		  <td><br><img src="/images/icon_disk.jpg" alt="Guardar �lbum"></td><td><b>Guardar �lbum</b><br><br>Guarda los cambios efectuados en el �lbum. Mientras no pulse este icono, los cambios que haya realizado no tendr�n efecto.</td>
		</tr>
		<tr>
		  <td><br><img src="/images/icon_derecha.jpg" alt="P�gina siguiente"></td><td><b>P�gina siguiente</b><br><br>Pasar a la p�gina siguiente.</td>
		</tr>
		<tr>
		  <td><br><img src="/images/icon_izquierda.jpg" alt="P�gina anterior"></td><td><b>P�gina anterior</b><br><br>Pasar a la p�gina anterior.</td>
		</tr>
		</table>
		
		<p align="center">[ <a href="http://www.mipeque.es">Volver</a> ]</p>
		
	  </div>	
	 </div>	 
	

</div>	

<div id="pie"><?php include("pie.php"); ?></div>

</body>
</html> 