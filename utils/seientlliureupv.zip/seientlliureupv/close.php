<?php

session_start();
session_destroy();
setcookie("pequenombre","",time()-3600);
setcookie("pequepass","",time()-3600);
header('Location: index.php');

?>
