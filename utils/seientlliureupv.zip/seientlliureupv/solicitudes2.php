<?php

include("include/bbdd.php");

$id=$_GET['id'];

//consulta a la bbdd
$ssql8 = "SELECT * FROM solicitudes WHERE id='".$id."'";
$resultConsul8 = mysql_query($ssql8);
$rowConsul8=mysql_fetch_object($resultConsul8);

//baja de la bbdd otra
$ssql7 = "DELETE FROM solicitudes WHERE id='".$id."'";
$resultConsul7 = mysql_query($ssql7);

//insertamos solicitud rechazada
$ssql9 = "INSERT INTO rechazadas (nombre,email,navegador,ip,fecha) VALUES ('".$rowConsul8->nombre."','".$rowConsul8->email."','".$rowConsul8->navegador."','".$rowConsul8->ip."',now())";
$resultConsul9 = mysql_query($ssql9);	  

header('Location: solicitudes.php?borrar=1');

?>