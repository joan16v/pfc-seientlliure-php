<?php

session_start();

//includes necesarios
include('include/defines.php');
include('include/bbdd.php');

if( isset($_SESSION['login'] ) ) {
 
   if( isset($_POST['nombre']) ) {
    
      $nombre=$_POST['nombre'];
	  $email=$_POST['email'];
	  if($_POST['aparecer']=="SI"){$aparecer=1;}else{$aparecer=0;};
	  
	  $ssql = "UPDATE usuarios SET nombre='".$nombre."', email='".$email."', aparecer='".$aparecer."' WHERE login=\"". $_SESSION['login'] ."\"";
	  $resultConsul = mysql_query($ssql);
	  
	  header('Location: admin.php');
	
   } else {
  
	   //consulta de los datos del usuario
	   $ssql = "SELECT * FROM usuarios WHERE login=\"". $_SESSION['login'] ."\"";
	   $resultConsul = mysql_query($ssql);
	   $rowConsul=mysql_fetch_object($resultConsul);
	  
	   ?>

	        <html>
			<head>
			<title>MiPeque.es | by DUSNIC | editar sus datos personales</title>
			<link href="estilos.css" rel="stylesheet" type="text/css">
			<?php include("./include/head.php"); ?>
			</head>
			
			<body>
			
			<div id="container" style="background:url(/images/<?php	echo "main_background_".rand(1, 2).".jpg";?>);">

				<div id="logo">
					<a href="index.php"><img src="images/logoMiPeque.gif" alt="Mi peque punto es (logotipo)" /></a>
				</div>			
		
				<div id="cuerpo">
				
				  <div id="buttons">				
				  </div>
				
		  		  <div id="login">
					<p><b>Editar datos</b></p><p>&nbsp;</p>
					<p>Usuario conectado: <b><?php echo $_SESSION['login']; ?></b> [ <a href="close.php">Cerrar sesi�n</a> ]</p><p>&nbsp;</p>					
				  </div>
				  
				  <div id="formularioEditar">
				  
				  <script>
				  
				  function mailvalido(texto){
			
						var mailres = true;            
						var cadena = "abcdefghijklmn�opqrstuvwxyzABCDEFGHIJKLMN�OPQRSTUVWXYZ1234567890@._-";
						
						var arroba = texto.indexOf("@",0);
						if ((texto.lastIndexOf("@")) != arroba) arroba = -1;
						
						var punto = texto.lastIndexOf(".");
									
						 for (var contador = 0 ; contador < texto.length ; contador++){
							if (cadena.indexOf(texto.substr(contador, 1),0) == -1){
								mailres = false;
								break;
						 }
						}
					
						if ((arroba > 1) && (arroba + 1 < punto) && (punto + 1 < (texto.length)) && (mailres == true) && (texto.indexOf("..",0) == -1))
						 mailres = true;
						else
						 mailres = false;
									
						return mailres;
					} 
					
					function emailt() {
					  email = document.getElementById('email').value;
					  
					  if ( mailvalido(email)==true ) { return true }
					  else { 
					    alert("El e-mail introducido no es v�lido.");
						return false; 
					  };
					  
					}
				  
				  function comprueba(){
				    if ( emailt()==false ) { return false };
					  identif = document.getElementById('nombre').value;
					  passw1 = document.getElementById('email').value;					  
					  if ( (identif=="") || (passw1=="") ) {
						alert("Rellene todos los campos!");
					  } else {
						document.getElementById('formulario').submit(); 
					  }	
				  }
				  
				  </script>
		
						  <form name="formulario" id="formulario" method="POST" action="edit_datos.php?action=1">
										  <table border="0">
												  <tbody>
													<tr>
														<td align="right">Nombre</td>
														<td><input type="text" name="nombre" id="nombre" value="<?php echo $rowConsul->nombre; ?>" size="25" /></td>				
													</tr>	
													<tr>
														<td align="right">E-mail</td>
														<td><input type="text" name="email" id="email" value="<?php echo $rowConsul->email; ?>" size="25" /></td>
													</tr>
													<tr>
														<td align="right">�Aparecer en listados?</td>
														<td>Si <input type="radio" name="aparecer" value="SI" <?php if($rowConsul->aparecer==1){ echo "checked"; }; ?>> No <input type="radio" name="aparecer" value="NO" <?php if($rowConsul->aparecer==0){ echo "checked"; }; ?>></td>													  
													</tr>
													<script>
													  function cancelar(){
													    history.back();	
													  }
													</script>
													<tr>
														<td align="right"><br> <input type="button" name="Submit" value="Actualizar datos" onClick="comprueba()" /></td>
														<td align="left"><br> <input type="button" name="cancel" value="Cancelar" onClick="cancelar()"></td>
													</tr>
												</tbody>
											</table>										
										     
						    </form>		
							
					</div>  				
				
				</div>
				
			</div>
			
			<div id="pie"><?php include("pie.php"); ?></div>	
			
			</body>
			</html> 

    <?php
    
      }

	} else {
	
	  header('Location: index.php');
	
	}

?>