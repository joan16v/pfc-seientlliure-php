<?php



session_start();



//includes necesarios

include('include/defines.php');

include('include/bbdd.php');



if( isset($_SESSION['login'] ) ) {

  

  ?>

  

  <html>

		<head>

		<title>MiPeque.es | by DUSNIC | zona de administraci�n de su �lbum</title>

		<link href="estilos.css" rel="stylesheet" type="text/css">
		
		<?php include("./include/head.php"); ?>

		</head>

		

		<body>

		

			<div id="container" style="background:url(/images/<?php	echo "main_background_".rand(1, 2).".jpg";?>);">

			<div id="logo">

					<a href="index.php"><img src="images/logoMiPeque.gif" alt="Mi peque punto es (logotipo)" /></a>

			</div>

		

			<div id="cuerpo">

	

				  <div id="buttons">					

				  </div>

			

		  		  <div id="login">

		  		    <?php if( isset($_GET['registro']) ) { echo "<p><img src=\"info.gif\"> Registro completado!</p>"; }; ?>

					<p>Conectado: <b><?php echo $_SESSION['login']; ?></b> [ <a href="close.php">Cerrar sesi�n</a> ]</p>

				  </div>

				  <p>&nbsp;</p>

				  <?php

				  

		  		    //consulta de los datos del usuario

					$ssql = "SELECT * FROM usuarios WHERE login=\"". $_SESSION['login'] ."\"";

		            $resultConsul = mysql_query($ssql);

		            $rowConsul=mysql_fetch_object($resultConsul);            

				  

				  ?>



				  <script language="JavaScript">

						function fullwin(){

								window.open("./<?php echo $_SESSION['login']; ?>","","fullscreen,scrollbars")

						}

						function fullwinAdmin(){

								window.open("./<?php echo $_SESSION['login']; ?>/admin","","fullscreen,scrollbars")

						}

 				  </script>

				  

				  <div id="datos">

					<table border="0"><tr valign="middle"><td><?php echo $rowConsul->nombre." ".$rowConsul->apellidos." | <a href=\"mailto:".$rowConsul->email."\">".$rowConsul->email."</a>"; ?></td><td><a href="edit_datos.php"><img border="0" src="/images/lapiz.gif" alt="Editar Datos"></a></td></tr></table>

				    <p>Tu �lbum: <a href="javascript:fullwin();">http://www.mipeque.es/<?php echo $_SESSION['login']; ?></a></p>

					<ul>

				    <script type="text/javascript">

						function mostrar() {

						window.open("mostrar.php", "popWindow", "toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=1, resizable=no, width=450, height=400")}

					</script>

					<li><a href="javascript:mostrar();">Muestra tu �lbum!</a></li>


				    <li><a href="http://portal.mipeque.es/index_web.php?webfile=recomendar.php&lefton=1">Recomendar la web a un amigo</a></li>

				    <script type="text/javascript">

							function invitar() {

							window.open("invitar.php" , "popWindow", "toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=1, resizable=no, width=450, height=400")}

					</script>

				    <li><a href="javascript:invitar();">Mandar invitaci�n (te quedan <?php echo $rowConsul->invitaciones; ?>)</a></li>

				    </ul>

				  </div>				  

				  

				  <div id="operaciones">

				    <p><b>Operaciones:</b></p>

					<p><a style="font-size:16px; font-weight:bolder" href="javascript:fullwinAdmin();">�CREA TU �LBUM!</a></p>

					

					<table border="0"><tr valign="middle"><td><a href="http://portal.mipeque.es/index_web.php?webfile=ayuda.php"><img border="0" src="/images/ayuda.jpg"></a></td><td><a href="http://portal.mipeque.es/index_web.php?webfile=ayuda.php">Ayuda</a></td><td> � <a href="http://portal.mipeque.es/index_web.php?webfile=sugerencias.php&lefton=1">�Alguna sugerencia?</a></td></tr></table>

					

				  </div>
				  
				  <p>&nbsp;</p><p><img src="images/flecha2.gif"> <a href="http://portal.mipeque.es/">�Ir al PORTAL de MiPeque.es!</a></p>	  
			  		

			</div>

			

		</div>	

		<div id="pie"><?php include("pie.php"); ?></div>

		</body>

		</html> 

  

  <?php



} else {



  header('Location: index.php');



}



?>