<?php

include("include/bbdd.php");

?>

<html>
<head>
<title>MiPeque.es | by DUSNIC | estad�sticas</title>
<link href="estilos.css" rel="stylesheet" type="text/css">
<?php include("./include/head.php"); ?>
</head>

<body>

<div id="container" style="background:url(/images/<?php	echo "main_background_".rand(1, 2).".jpg";?>);">

	<div id="logo">
		<a href="index.php"><img src="images/logoMiPeque.gif" alt="Mi peque punto es (logotipo)" /></a>
	</div>			

	<div id="cuerpo"> 
				
		<p><b>Estad�sticas</b></p>
		
		<?php 
		
		$ssql8 = "SELECT * FROM usuarios";
		$resultConsul8 = mysql_query($ssql8);
		$numrows=mysql_num_rows($resultConsul8);
		$numalbums=$numrows-4; 			
		
		$ssql9 = "SELECT * FROM usuarios WHERE aparecer='0'";
		$resultConsul9 = mysql_query($ssql9);
		$numrows=mysql_num_rows($resultConsul9);
		$numalbumsoc=$numrows-4; 		
		
		$ssql7 = "SELECT sum(visitas) as valor FROM usuarios";
		$resultConsul7 = mysql_query($ssql7);
		$rowConsul7=mysql_fetch_object($resultConsul7);
		$visitasalbums=$rowConsul7->valor; 
		
		$ssql6 = "SELECT sum(invitaciones) as valor FROM usuarios";
		$resultConsul6 = mysql_query($ssql6);
		$rowConsul6=mysql_fetch_object($resultConsul6);
		$invitaciones=$rowConsul6->valor; 		
		
		$ssql5 = "SELECT count(*) as valor FROM codigos";
		$resultConsul5 = mysql_query($ssql5);
		$rowConsul5=mysql_fetch_object($resultConsul5);
		$numcodigos=$rowConsul5->valor; 			
		
		$ssql4 = "SELECT count(*) as valor FROM solicitudes";
		$resultConsul4 = mysql_query($ssql4);
		$rowConsul4=mysql_fetch_object($resultConsul4);
		$numsolicitudes1=$rowConsul4->valor; 
		
		$ssql3 = "SELECT count(*) as valor FROM aceptadas";
		$resultConsul3 = mysql_query($ssql3);
		$rowConsul3=mysql_fetch_object($resultConsul3);
		$numsolicitudes2=$rowConsul3->valor; 		
		
		$ssql2 = "SELECT count(*) as valor FROM rechazadas";
		$resultConsul2 = mysql_query($ssql2);
		$rowConsul2=mysql_fetch_object($resultConsul2);
		$numsolicitudes3=$rowConsul2->valor; 		
		
		$totalsolicitudes=$numsolicitudes1+$numsolicitudes2+$numsolicitudes3;
		
		$hoy = getdate();
		$dia_hoy=$hoy['mday'];
		$mes_hoy=$hoy['mon'];
		if( strlen($dia_hoy)==1 ) { $dia_hoy="0".$dia_hoy; };
		if( strlen($mes_hoy)==1 ) { $mes_hoy="0".$mes_hoy; };		
        $fecha_actual=$hoy['year']."-".$mes_hoy."-".$dia_hoy;
    
		$ssql18 = "SELECT * FROM usuarios WHERE fecha like '%".$fecha_actual."%'";
		$resultConsul18 = mysql_query($ssql18);
		$albumeshoy=mysql_num_rows($resultConsul18);
		
		function resta_fechas($fecha1,$fecha2) {	            
		
		      if (preg_match("/[0-9]{1,2}\/[0-9]{1,2}\/([0-9][0-9]){1,2}/",$fecha1))          
				              list($dia1,$mes1,$a�o1)=split("/",$fecha1);
		           
		      if (preg_match("/[0-9]{1,2}-[0-9]{1,2}-([0-9][0-9]){1,2}/",$fecha1))		       
		
		              list($dia1,$mes1,$a�o1)=split("-",$fecha1);
		        if (preg_match("/[0-9]{1,2}\/[0-9]{1,2}\/([0-9][0-9]){1,2}/",$fecha2))		            
		
		              list($dia2,$mes2,$a�o2)=split("/",$fecha2);		            
		
		      if (preg_match("/[0-9]{1,2}-[0-9]{1,2}-([0-9][0-9]){1,2}/",$fecha2))		            
		
		        list($dia2,$mes2,$a�o2)=split("-",$fecha2);
		        $dif = mktime(0,0,0,$mes1,$dia1,$a�o1) - mktime(0,0,0,$mes2,$dia2,$a�o2);		            
		
		      $ndias=floor($dif/(24*60*60));		            
		
		      return($ndias);		            
		
		}
     
        $f1="16-01-2007";
        $totalDias=resta_fechas(date("d/m/Y"),$f1);     
        $albumesDia=round($numalbums/$totalDias,2);
        
		$ssql28 = "SELECT * FROM solicitudes WHERE fecha like '%".$fecha_actual."%'";
		$resultConsul28 = mysql_query($ssql28);
		$solicitudes_hoy_1=mysql_num_rows($resultConsul28);    
		
		$ssql38 = "SELECT * FROM aceptadas WHERE fecha like '%".$fecha_actual."%'";
		$resultConsul38 = mysql_query($ssql38);
		$solicitudes_hoy_2=mysql_num_rows($resultConsul38);   		    
		
		$ssql48 = "SELECT * FROM rechazadas WHERE fecha like '%".$fecha_actual."%'";
		$resultConsul48 = mysql_query($ssql48);
		$solicitudes_hoy_3=mysql_num_rows($resultConsul48);   		
			
 		$solicitudes_hoy=$solicitudes_hoy_1+$solicitudes_hoy_2+$solicitudes_hoy_3;
	
		?>
		
		<p>N�mero de �lbums creados: <b><?php echo $numalbums; ?></b> (<?php echo $numalbumsoc; ?> de ellos ocultos).</p>
		<p>Visitas totales a los �lbumes: <b><?php echo $visitasalbums; ?></b>.</p>
		<p>N�mero de invitaciones totales que les quedan a los usuarios: <b><?php echo $invitaciones; ?></b>.</p>
		<p>N�mero de c�digos de activaci�n usados: <b><?php echo $numcodigos; ?></b>.</p>
		<p>N�mero solicitudes realizadas: <b><?php echo $totalsolicitudes; ?></b> (<?php echo $solicitudes_hoy; ?> hoy).</p>
		<p>�lbumes creados hoy: <b><?php echo $albumeshoy; ?></b>.</p>
		<p>Media: <b><?php echo $albumesDia; ?></b> �lbumesCreados/Dia.</p>
		
		<div style="padding:5px;border:1px solid #000000;width:320px;height:130px;overflow:auto;">Listado de TODOS los �lbums (en azul los creados HOY):<br><br>
		
		<?php
		
		$ssql10 = "SELECT * FROM usuarios ORDER BY login ASC";
		$resultConsul10 = mysql_query($ssql10);
		while($rowConsul10=mysql_fetch_object($resultConsul10)){
			if( ($rowConsul10->login!="album_archivos") && ($rowConsul10->login!="include") && ($rowConsul10->login!="images") && ($rowConsul10->login!="old_mipeque") ){ 
			  if( $rowConsul10->aparecer==1 ){	
			    if( $fecha_actual==substr($rowConsul10->fecha,0,10) ) {  
					echo "<a style=\"color:#0000FF\" href=\"http://www.mipeque.es/".$rowConsul10->login."\">".$rowConsul10->login."</a><br>";					
				} else {
					echo "<a href=\"http://www.mipeque.es/".$rowConsul10->login."\">".$rowConsul10->login."</a><br>";					
				};			

			  } else {
			     if( $fecha_actual==substr($rowConsul10->fecha,0,10) ) {
					 echo "<a style=\"color:#0000FF\" href=\"http://www.mipeque.es/".$rowConsul10->login."\">".$rowConsul10->login."</a> (oculto)<br>";
				 } else {
				     echo "<a href=\"http://www.mipeque.es/".$rowConsul10->login."\">".$rowConsul10->login."</a> (oculto)<br>";	
				 }     
				 				
			  } 
		    };
		}		
		
		?>
		
		</div>
	
	</div>
	
</div>

<div id="pie"><?php include("pie.php"); ?></div>	

</body>
</html> 