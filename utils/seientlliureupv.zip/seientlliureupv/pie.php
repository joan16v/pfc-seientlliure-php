<script>
  function avisoLegal() {
    window.open("condiciones.php" , "popWindow", "toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=1, resizable=no, width=450, height=400")	
  }
</script>
<p><a href="javascript:avisoLegal();">Aviso Legal</a> | Desarrollado por <a target="_blank" href="http://www.dusnic.es">Dusnic S.L.</a></p><p>Optimizado para 1024x768</p>