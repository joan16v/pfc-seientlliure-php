<?php

session_start();
function ValidarDatos($campo){
    //Array con las posibles cabeceras a utilizar por un spammer
    $badHeads = array("Content-Type:",
                                 "MIME-Version:",
                                 "Content-Transfer-Encoding:",
                                 "Return-path:",
                                 "Subject:",
                                 "From:",
                                 "Envelope-to:",
                                 "To:",
                                 "bcc:",
                                 "cc:");

    //Comprobamos que entre los datos no se encuentre alguna de
    //las cadenas del array. Si se encuentra alguna cadena se
    //dirige a una p�gina de Forbidden
    foreach($badHeads as $valor){
      if(strpos(strtolower($campo), strtolower($valor)) !== false){
        header("location: /index.php");
        exit;
      }
    }
  }
  
include('include/bbdd.php');

if(isset($_POST['nombreamigo'])) {
ValidarDatos($_POST['code']);
if ($_POST['code']==$_SESSION['code']){
 ValidarDatos($_POST['nombreamigo']);
  ValidarDatos($_POST['emailamigo']);
  
  $ssql8 = "SELECT * FROM usuarios WHERE login=\"". $_SESSION['login'] ."\"";
  $resultConsul8 = mysql_query($ssql8);
  $rowConsul8=mysql_fetch_object($resultConsul8);
  //echo $rowConsul->nombre;

  $sunombre=$rowConsul8->nombre;
  $suemail=$rowConsul8->email;
  $nombreamigo=$_POST['nombreamigo'];
  $emailamigo=$_POST['emailamigo'];
  
  $asunto="Soy ".$sunombre.", mira el �lbum de fotos de mi peque!";
  $contenido="Hola ".$nombreamigo."!<br><br>Soy ".$sunombre.", visita esta p�gina web <a href=\"http://www.mipeque.es/".$_SESSION['login']."\">http://www.mipeque.es/".$_SESSION['login']."</a>, para ver el �lbum de fotos de mi peque.<br><br>Un saludo.";
  
  $headers = "From:$suemail\nReply-To:$suemail\n";
  $headers .= "X-Mailer:PHP/".phpversion()."\n";
  $headers .= "Mime-Version: 1.0\n";
  $headers .= "Content-Type: text/html";
  
  //subo en la bbdd para recopilacion de estadisticas 
  $ssql8 = "INSERT INTO muestras (nombre,email,nombreamigo,emailamigo) VALUES ('".$sunombre."','".$suemail."','".$nombreamigo."','".$emailamigo."')";
  $resultConsul8 = mysql_query($ssql8);  
  
  mail($emailamigo,$asunto,$contenido,$headers);
  
?>

	<html>
	<head>
	<title>MiPeque.es | muestra tu �lbum a un amigo!</title>
	<link href="estilos.css" rel="stylesheet" type="text/css">
	</head>
	<body>
	<h2>Muestra tu �lbum!</h2>
	<p>Listo! Ha recomendado visitar a <?php echo $nombreamigo; ?> tu �lbum de mipeque.es!</p>
	<p><a href="javascript:window.close();">[ Cerrar Ventana ]</a></p>
	</form>
	</body>
	</html>

<?php  
	}
	else{
	?>

	<html>
	<head>
	<title>MiPeque.es | muestra tu �lbum a un amigo!</title>
	<link href="estilos.css" rel="stylesheet" type="text/css">
	</head>
	<body>
	<h2>Muestra tu �lbum!</h2>
	<p>El c�digo es erroneo.</p>
	<p><a href="javascript:history.back();">[ Volver ]</a></p>
	</form>
	</body>
	</html>

<?php 	
	}
} else {

?>

	<html>
	<head>
	<title>MiPeque.es | muestra tu �lbum a un amigo!</title>
	<link href="estilos.css" rel="stylesheet" type="text/css">
	<script>
			function comprueba() {			  			  
			  nombre = document.getElementById('nombreamigo').value;
			  email = document.getElementById('emailamigo').value;			  
			  if ( (nombre=="") || (email=="") ) {
				alert("Rellene todos los campos!");
			  } else {
				document.getElementById('formulario').submit(); 
			  }			  
			}
	</script>	
	</head>
	<body>
	<h2>Muestra tu �lbum!</h2>
	<p>Muestra el �lbum que has creado a un amigo/a tuyo.</p>
	<form action="mostrar.php" method="post" name="formulario" id="formulario">
	<table border="0">
	<tr>
	  <td align="right">Nombre de tu amigo</td><td><input type="text" name="nombreamigo" id="nombreamigo" size="20"></td>
	</tr>
	<tr>
	  <td align="right">E-mail de tu amigo</td><td><input type="text" name="emailamigo" id="emailamigo" size="20"></td>
	</tr>
	<tr>
		<td rowspan="2" valign="top"><strong>N� de confirmaci�n:</strong></td>
	    <td>
	        Para evitar consultas automatizadas reescriba el n�mero siguiente:<br>
	        <script>document.write('<img src="code.php?noCache='+ Math.random() +'">');</script>
	    </td> 
	</tr> 
	<tr>
	    <td><input name="code" size="29" type="text"></td> 
	</tr>
	</table>
	<p><input type="button" value="Enviar" onClick="comprueba()"></p>
	<p><a href="javascript:window.close();">[ Cerrar Ventana ]</a></p>
	</form>
	</body>
	</html>

<?php

}

?>