<?
	//este thumb.php a�ade borde blanco 

        $fuente = @imagecreatefromjpeg($_GET[foto]);
	$im = $fuente;
	$max_width= 150;
	$max_height = 100;

	$size[0]=imagesx($fuente);
	$size[1]=imagesy($fuente);

	$width_ratio  = ($size[0] / $max_width);
	$height_ratio = ($size[1] / $max_height);

	if($width_ratio >= $height_ratio)
	{
	   $ratio = $width_ratio;
	}
	else
	{
	   $ratio = $height_ratio;
	}

	$new_width    = ($size[0] / $ratio);
	$new_height   = ($size[1] / $ratio);

	$imagen = imagecreatetruecolor($new_width-1,$new_height-1);
	ImageCopyResized($imagen,$fuente,0,0,0,0,$new_width,$new_height,$size[0],$size[1]);
	header("Content-type: image/jpeg");
	//imageJpeg($imagen,"",100);

        $alto = $new_height+10;
        $ancho = $new_width+10;
        $im = imagecreatetruecolor($ancho,$alto);
        //definimos algunos colores
        $grey = imagecolorallocate($im, 107,107,107);
        $white = imagecolorallocate($im, 255,255,255);
        //creamos un primer fondo liso
        imagefill($im,0,0,$white);
        //creamos los bordes
        imageline($im, 0,0, $ancho, 0,$grey);
        imageline($im, $ancho-1,0, $ancho-1, $alto, $grey);
        imageline($im, 0, $alto-1 , $ancho, $alto-1, $grey);
        imageline($im, 0,$alto, 0, 0,$grey);
        // bordes internos
        //imageline($im, 2,2, $ancho-3, 2,$grey);
        //imageline($im, $ancho-3,2, $ancho-3, $alto-3, $grey);
        //imageline($im, 2, $alto-3 , $ancho-3, $alto-3, $grey);
        //imageline($im, 2,$alto-3, 2, 2,$grey);

        imagecopymerge($im, $imagen, 5,5, 0,0, $new_width, $new_height, 100);
        //realizamos la salida al navegador
        imageJpeg ($im);
        imagedestroy($im);
?>
