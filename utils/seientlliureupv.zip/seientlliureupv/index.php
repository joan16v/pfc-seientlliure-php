<?php

//inicio de sesion
session_start();

//conexion a bbdd
include('include/bbdd.php');

if( isset($_COOKIE['pequenombre']) ) { 
 
 $consulta="SELECT * FROM usuarios WHERE login='".$_COOKIE['pequenombre']."' and password='".$_COOKIE['pequepass']."'";
 $query=mysql_query($consulta);
 $numRows=mysql_num_rows($query); 
 
 if( $numRows==1 ) {  $_SESSION['login']=$_COOKIE['pequenombre']; };

}

if( isset($_SESSION['login']) ) {
	
	header('Location: admin.php');
	
} else {
	
	if( isset($_GET['action'] ) ) { $action=$_GET['action']; };
	if( !isset($action) ) { $action=0; };
	
	switch ($action) {
		
		case 1:		
		
		  $login=$_POST['login'];
		  $password=$_POST['password'];
		  
		  $consulta="SELECT * FROM usuarios WHERE login='".$login."' and password='".$password."'";
		  $query=mysql_query($consulta);
		  $numRows=mysql_num_rows($query);
		  
		  if( $numRows==1 ) {  
		   
		    if ( ($login=="images") || ($login=="include") || ($login=="old_mipeque") || ($login=="album_archivos") ) {
		     
			    //login error
				header('Location: index.php?error=1');		     
				
			} else {
			 
	 		    //login y pass correcto	
			    $_SESSION['login']=$login;
			    if( $_POST['recordar']=="on" ){ 
				  setcookie("pequenombre",$login,time()+100*24*60*60); //cookies de 100 dias
				  setcookie("pequepass",$password,time()+100*24*60*60);
				}
			    header('Location: admin.php');
				
			}		    
		
		  } else {
		
		    //login error
			header('Location: index.php?error=1');
			
		  }
		
		break;
		
		default:
		
		?>	
	
			<html>
			<head>
			<title>Seient Lliure</title>
			<meta name="title" content="">
			<meta http-equiv="keywords" content="">
			<link href="estilos.css" rel="stylesheet" type="text/css">			
			<script type="text/javascript" src="include/swfobject.js"></script>			
			</head>
			
			<body>
				<div id="container">
				<div id="logo">

				</div>
				
				<div id="cuerpo">
				

						
					<div id="boxUsuarios">
					
					<?php
					
					  if( isset($_SESSION['login']) ) {
					
					?>
					
						<p>Usuario conectado: <b><?php echo $_SESSION['login']; ?></b>. <a href="close.php">Cerrar sesi�n</p></p>
						
					<?php
					
					  } else {
					
					?>				

						<div id="formloginpass">
						
							<?php if( isset($_GET['nologin']) ) { echo "<p style=\"margin:0px;\" class=\"error\"><img src=\"info.gif\"> No se ha identificado.</p>"; }; ?>
							
							<?php if( isset($_GET['passsend']) ) { echo "<p style=\"margin:0px;\" class=\"error\"><img src=\"info.gif\"> Se ha enviado la contrase�a a su e-mail.</p>"; }; ?>
	
							<?php if( isset($_GET['error']) ) { echo "<p style=\"margin:0px;\" class=\"error\"><img src=\"info.gif\"> Nombre de �lbum o contrase�a incorrecto.</p>"; }; ?>
							
							<?php if( isset($_GET['registro']) ) { echo "<p style=\"margin:0px;\"><img src=\"info.gif\"> Registro completado. Ahora puede hacer login.</p>"; }; ?>
							
							<?php if( isset($_GET['solicitud']) ) { echo "<p style=\"margin:0px;\"><img src=\"info.gif\"> Su solicitud ha sido enviada.</p>"; }; ?>						
						
							<form method="post" action="index.php?action=1" name="cuenta" id="cuenta">
								<table summary="zonaclientes" border="0"> 
								 <tr> 
									<td align="right"><label for="login">login</label></td> 
								    <td><input type="text" name="login" id="login" size="25" value="suAlbum" onFocus="this.value=''"></td> 
								 </tr> 
								 <tr> 
									<td align="right"><label for="password">contrase�a</label></td> 
									<td align="right"><input type="password" name="password" id="password" size="25" value="suPassword" onFocus="this.value=''"><br><span style="font-size:9px"><a href="olvidado.php">�Ha olvidado su contrase�a?</a></span></td> 				
								 </tr>
								</table> 
								<div align="right">
								<table summary="zonaclientes2" border="0">
								 <tr> 
									<td align="right"><input type="checkbox" name="recordar">Recordar contrase�a </td> 
									<td align="right"><input type="submit" id="enviar" name="enviar" value="entrar"></td> 
								 </tr> 								
								</table>
								</div>
							</form>
                       </div>							
					
					<?php
					
					}
					
					?>
					
					</div>
				</div>
			</div>
			
			<div id="pie"><?php include("pie.php"); ?></div>
			
			</body>
			</html>
	
	<?php
		
		break;
		
	} //fin del switch
	
} //fin del primer else

?>