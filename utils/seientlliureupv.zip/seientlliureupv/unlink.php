<?php
//
// Comprobaciones previas de la ruta del fichero
//

require_once('album_archivos/xml_domit_include.php');

$filename = $_POST['file2del'];
$fullPath = $_SERVER['DOCUMENT_ROOT'] . substr($_SERVER["REQUEST_URI"],0,strpos($_SERVER["REQUEST_URI"],"/",1)) . "/admin/";
$FPfilename =  $fullPath . "fotos/". $filename ; // Nombre con el path completo.

//nombre de la imagen (sin el directorio fotos

$x = unlink($FPfilename);

//comprueba que no exita el fichero
$y = is_file($FPfilename);

//si no existe el fichero, quitamos del xml la info
if (!$y) {
   
    $doc =& new DOMIT_Document();
    $success= $doc->loadXML($fullPath . "imageList.xml"); 
    
    //Localizamos el elemento que contiene el nombre de la imagen que buscamos
	$myTextNodeList =& $doc->getNodesByNodeValue($filename, $doc);
	
	//Tan s�lo debe haber una imagen con el nombre elegido, pero por si las moscas tomamos el primer elemento
	$firstItem =& $myTextNodeList->item(0);
	
	//Mostramos el nodo que deseamos borrar
	//echo $firstItem->parentNode->toNormalizedString(true);
	
	//Eliminamos el nodo que queremos borrar.
	$doc->documentElement->removeChild($firstItem->parentNode);
	
	//Guardamos el XML en el fichero correspondiente.
	$doc->saveXML($fullPath ."imageList.xml", true);    
    
}
?>